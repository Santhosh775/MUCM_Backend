const Application = require('./applicationModel');
const PersonalDetails = require('./personalDetailsModel');
const EmergencyContact = require('./emergencyContactModel');
const ParentGuardianInfo = require('./parentGuardianInfoModel');
const AcademicInstitution = require('./academicInstitutionModel');
const EnglishProficiency = require('./englishProficiencyModel');
const StandardizedTest = require('./standardizedTestModel');
const AdmissionSought = require('./admissionSoughtModel');
const Disclosure = require('./disclosureModel');
const Experience = require('./experienceModel');
const Document = require('./documentModel');
const PrerequisiteDocument = require('./prerequisiteDocumentModel');
const ApplicationUser = require('./applicationUserModel');
const ApplicationUserLogin = require('./applicationUserLoginModel');
const PortalApplicationDraft = require('./portalApplicationDraftModel');
const FinancialSupport = require('./financialSupportModel');
const Tenant = require('./tenantModel');
const Program = require('./programModel');
const Intake = require('./intakeModel');
const Lead = require('./leadModel');
const PipelineStage = require('./pipelineStageModel');
const Faq = require('./faqModel');
const SupportTicket = require('./supportTicketModel');

Application.hasOne(PersonalDetails, { foreignKey: 'application_id', as: 'personal_details' });
PersonalDetails.belongsTo(Application, { foreignKey: 'application_id', as: 'application' });

Application.hasMany(EmergencyContact, { foreignKey: 'application_id', as: 'emergency_contacts' });
EmergencyContact.belongsTo(Application, { foreignKey: 'application_id', as: 'application' });

Application.hasOne(ParentGuardianInfo, { foreignKey: 'application_id', as: 'parent_guardian_info' });
ParentGuardianInfo.belongsTo(Application, { foreignKey: 'application_id', as: 'application' });

Application.hasMany(AcademicInstitution, { foreignKey: 'application_id', as: 'academic_institutions' });
AcademicInstitution.belongsTo(Application, { foreignKey: 'application_id', as: 'application' });

Application.hasOne(EnglishProficiency, { foreignKey: 'application_id', as: 'english_proficiency' });
EnglishProficiency.belongsTo(Application, { foreignKey: 'application_id', as: 'application' });

Application.hasMany(StandardizedTest, { foreignKey: 'application_id', as: 'standardized_tests' });
StandardizedTest.belongsTo(Application, { foreignKey: 'application_id', as: 'application' });

Application.hasOne(AdmissionSought, { foreignKey: 'application_id', as: 'admission_sought' });
AdmissionSought.belongsTo(Application, { foreignKey: 'application_id', as: 'application' });

Application.hasOne(Disclosure, { foreignKey: 'application_id', as: 'disclosure' });
Disclosure.belongsTo(Application, { foreignKey: 'application_id', as: 'application' });

Application.hasMany(Experience, { foreignKey: 'application_id', as: 'experiences' });
Experience.belongsTo(Application, { foreignKey: 'application_id', as: 'application' });

Application.hasOne(Document, { foreignKey: 'application_id', as: 'document' });
Document.belongsTo(Application, { foreignKey: 'application_id', as: 'application' });

ApplicationUser.hasMany(ApplicationUserLogin, { foreignKey: 'user_id', as: 'logins' });
ApplicationUserLogin.belongsTo(ApplicationUser, { foreignKey: 'user_id', as: 'user' });

ApplicationUser.hasMany(PortalApplicationDraft, { foreignKey: 'user_id', as: 'portal_application_drafts' });
PortalApplicationDraft.belongsTo(ApplicationUser, { foreignKey: 'user_id', as: 'user' });

Application.hasMany(PortalApplicationDraft, { foreignKey: 'application_id', as: 'portal_drafts' });
PortalApplicationDraft.belongsTo(Application, { foreignKey: 'application_id', as: 'application' });

ApplicationUser.hasOne(PrerequisiteDocument, { foreignKey: 'user_id', as: 'prerequisite_document' });
PrerequisiteDocument.belongsTo(ApplicationUser, { foreignKey: 'user_id', as: 'user' });

Application.hasOne(FinancialSupport, { foreignKey: 'application_id', as: 'financial_support' });
FinancialSupport.belongsTo(Application, { foreignKey: 'application_id', as: 'application' });

Tenant.hasMany(Program, { foreignKey: 'tenant_id', as: 'programs' });
Program.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });

Tenant.hasMany(Intake, { foreignKey: 'tenant_id', as: 'intakes' });
Intake.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });

Tenant.hasMany(Lead, { foreignKey: 'tenant_id', as: 'leads' });
Lead.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });

Tenant.hasMany(PipelineStage, { foreignKey: 'tenant_id', as: 'pipeline_stages' });
PipelineStage.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });

Program.hasMany(Intake, { foreignKey: 'program_id', as: 'intakes' });
Intake.belongsTo(Program, { foreignKey: 'program_id', as: 'program' });

Tenant.hasMany(Application, { foreignKey: 'tenant_id', as: 'applications' });
Application.belongsTo(Tenant, { foreignKey: 'tenant_id', as: 'tenant' });

Program.hasMany(Application, { foreignKey: 'program_id', as: 'applications' });
Application.belongsTo(Program, { foreignKey: 'program_id', as: 'program' });

Intake.hasMany(Application, { foreignKey: 'intake_id', as: 'applications' });
Application.belongsTo(Intake, { foreignKey: 'intake_id', as: 'intake' });

Lead.hasMany(Application, { foreignKey: 'lead_id', as: 'applications' });
Application.belongsTo(Lead, { foreignKey: 'lead_id', as: 'lead' });

PipelineStage.hasMany(Application, { foreignKey: 'pipeline_stage_id', as: 'applications' });
Application.belongsTo(PipelineStage, { foreignKey: 'pipeline_stage_id', as: 'pipeline_stage' });

ApplicationUser.hasMany(SupportTicket, { foreignKey: 'user_id', as: 'support_tickets' });
SupportTicket.belongsTo(ApplicationUser, { foreignKey: 'user_id', as: 'user' });

module.exports = {
    Application,
    PersonalDetails,
    EmergencyContact,
    ParentGuardianInfo,
    AcademicInstitution,
    EnglishProficiency,
    StandardizedTest,
    AdmissionSought,
    Disclosure,
    Experience,
    Document,
    PrerequisiteDocument,
    ApplicationUser,
    ApplicationUserLogin,
    PortalApplicationDraft,
    FinancialSupport,
    Tenant,
    Program,
    Intake,
    Lead,
    PipelineStage,
    Faq,
    SupportTicket
};

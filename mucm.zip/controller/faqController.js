const { Faq } = require('../model/associations');

exports.listPublished = async (req, res) => {
    try {
        const rows = await Faq.findAll({
            where: { deleted_at: null, is_published: true },
            order: [
                ['sort_order', 'ASC'],
                ['created_at', 'ASC']
            ],
            attributes: ['id', 'category', 'question', 'answer', 'sort_order', 'created_at']
        });
        return res.json({ success: true, data: rows });
    } catch (error) {
        console.error('listPublished faq', error);
        return res.status(500).json({ success: false, message: error.message || 'Server error' });
    }
};

exports.listAll = async (req, res) => {
    try {
        const rows = await Faq.findAll({
            where: { deleted_at: null },
            order: [
                ['sort_order', 'ASC'],
                ['created_at', 'DESC']
            ]
        });
        return res.json({ success: true, data: rows });
    } catch (error) {
        console.error('listAll faq', error);
        return res.status(500).json({ success: false, message: error.message || 'Server error' });
    }
};

exports.create = async (req, res) => {
    try {
        const payload = {
            category: req.body.category?.trim() || 'General',
            question: req.body.question.trim(),
            answer: req.body.answer.trim(),
            sort_order: req.body.sort_order != null ? Number(req.body.sort_order) : 0,
            is_published: req.body.is_published !== false
        };
        const row = await Faq.create(payload);
        return res.status(201).json({ success: true, message: 'FAQ created', data: row });
    } catch (error) {
        console.error('create faq', error);
        return res.status(500).json({ success: false, message: error.message || 'Server error' });
    }
};

exports.update = async (req, res) => {
    try {
        const row = await Faq.findOne({
            where: { id: req.params.id, deleted_at: null }
        });
        if (!row) return res.status(404).json({ success: false, message: 'FAQ not found' });

        const next = {};
        if (req.body.category !== undefined) next.category = String(req.body.category).trim() || 'General';
        if (req.body.question !== undefined) next.question = String(req.body.question).trim();
        if (req.body.answer !== undefined) next.answer = String(req.body.answer).trim();
        if (req.body.sort_order !== undefined) next.sort_order = Number(req.body.sort_order);
        if (req.body.is_published !== undefined) next.is_published = Boolean(req.body.is_published);

        await row.update(next);
        return res.json({ success: true, message: 'FAQ updated', data: row });
    } catch (error) {
        console.error('update faq', error);
        return res.status(500).json({ success: false, message: error.message || 'Server error' });
    }
};

exports.remove = async (req, res) => {
    try {
        const row = await Faq.findOne({
            where: { id: req.params.id, deleted_at: null }
        });
        if (!row) return res.status(404).json({ success: false, message: 'FAQ not found' });
        await row.update({ deleted_at: new Date() });
        return res.json({ success: true, message: 'FAQ deleted' });
    } catch (error) {
        console.error('remove faq', error);
        return res.status(500).json({ success: false, message: error.message || 'Server error' });
    }
};
